var Constants = {
  VAIR : "vAir",
  VTHING : "vThing - CO2",
  VESPRINO_V1 : "vESPrino",
  VTHING_H801 : "vThing - H8",
  VTHING_STARTER : "sadsa"
}
